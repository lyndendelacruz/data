import { parseCSV } from "./src/utils/csvParser.js";
import { createNceCard, createSoftwareCard } from "./src/components/productCard.js";

/* ---------------- DEBOUNCE ---------------- */
function debounce(fn, delay = 150) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

/* ---------------- SEGMENT CLASS HELPER ---------------- */
function getSegmentIconClass(segment) {
  if (!segment) return "segment-other";

  const key = segment.toLowerCase();

  if (key.includes("commercial")) return "segment-commercial";
  if (key.includes("education")) return "segment-education";
  if (key.includes("charity") || key.includes("nonprofit")) return "segment-charity";

  return "segment-other";
}

export { getSegmentIconClass };

/* ---------------- GLOBAL STATE ---------------- */
let nceProducts = [];
let softwareProducts = [];
let activeProducts = [];
let activeView = "nce";

/* ---------------- GITHUB TIMESTAMP FETCHER ---------------- */
async function fetchGitHubTimestamp(path) {
  try {
    const apiUrl =
      `https://api.github.com/repos/lyndendelacruz/data/commits?path=${path}&page=1&per_page=1`;

    const response = await fetch(apiUrl);
    const commits = await response.json();

    if (Array.isArray(commits) && commits.length > 0) {
      return commits[0].commit.author.date;
    }
  } catch (err) {
    console.warn("Failed to fetch GitHub timestamp:", err);
  }

  return null;
}

/* ---------------- CSV NORMALIZER ---------------- */
function normalizeProduct(p) {
  return {
    ProductTitle: p.ProductTitle || "",
    ProductID: p.ProductID || p.ProductId || "",
    SKU: p.SKU || p.SkuId || "",
    BillingPlan: p.BillingPlan || "",
    Segment: p.Segment || "",
    TermDuration: p.TermDuration || "",
    Currency: p.Currency || "",
    Price: p.Price || p.UnitPrice || "",
    Tags: p.Tags || "",
    ...p
  };
}

/* ---------------- CSV LOADER ---------------- */
async function loadCSV(localPath, remoteUrl, timestampPath) {
  const sourceLabel = document.getElementById("dataSource");

  try {
    const response = await fetch(remoteUrl);
    if (!response.ok) throw new Error("Remote fetch failed");

    const text = await response.text();

    sourceLabel.textContent = "Data source: Live (GitHub)";
    sourceLabel.style.color = "limegreen";

    /* ---------------- TRUE GITHUB TIMESTAMP ---------------- */
    const tsEl = document.getElementById("lastUpdated");
    if (tsEl) {
      const commitDate = await fetchGitHubTimestamp(timestampPath);

      if (commitDate) {
        const formatted = new Date(commitDate).toLocaleString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        });

        tsEl.textContent = `Last updated: ${formatted}`;
      } else {
        tsEl.textContent = "Last updated: unknown";
      }
    }
    /* ------------------------------------------------------- */

    return parseCSV(text).map(normalizeProduct);

  } catch (err) {
    console.warn("Remote load failed, falling back to local:", err);

    const local = chrome.runtime.getURL(localPath);
    const response = await fetch(local);
    const text = await response.text();

    sourceLabel.textContent = "Data source: Local fallback";
    sourceLabel.style.color = "orange";

    return parseCSV(text).map(normalizeProduct);
  }
}

/* ---------------- FILTER BUILDING ---------------- */
function buildDropdown(id, values, label) {
  const select = document.getElementById(id);
  select.innerHTML = `<option value="">All ${label}</option>`;
  values.forEach(v => {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = v;
    select.appendChild(opt);
  });
}

function buildFilters(list) {
  const segments = [...new Set(list.map(p => p.Segment).filter(Boolean))].sort();
  const billing = [...new Set(list.map(p => p.BillingPlan).filter(Boolean))].sort();

  buildDropdown("segmentFilter", segments, "segments");
  buildDropdown("billingFilter", billing, "billing plans");

  if (activeView === "nce") {
    const terms = [...new Set(list.map(p => p.TermDuration).filter(Boolean))].sort();
    buildDropdown("termFilter", terms, "terms");
    document.getElementById("termFilter").style.display = "block";
    document.getElementById("tagFilter").style.display = "none";
  } else {
    const tags = [...new Set(
      list.flatMap(p => (p.Tags || "").split(";").filter(Boolean))
    )].sort();

    buildDropdown("tagFilter", tags, "tags");

    document.getElementById("tagFilter").style.display = "block";
    document.getElementById("termFilter").style.display = "none";
  }
}

/* ---------------- SEARCH + FILTER PIPELINE ---------------- */
function searchProducts(list, query) {
  const q = query.trim().toLowerCase();
  if (!q) return list;
  return list.filter(p => (p.ProductTitle || "").toLowerCase().includes(q));
}

function applyFilters(list, filters) {
  return list.filter(p => {
    if (filters.segment && p.Segment !== filters.segment) return false;
    if (filters.billing && p.BillingPlan !== filters.billing) return false;

    if (activeView === "nce") {
      if (filters.term && p.TermDuration !== filters.term) return false;
    } else {
      if (filters.tag && !(p.Tags || "").split(";").includes(filters.tag)) return false;
    }

    return true;
  });
}

function getResults(query, filters) {
  let result = searchProducts(activeProducts, query);
  result = applyFilters(result, filters);
  return result;
}

/* ---------------- PRICE CALCULATION ---------------- */
function applyBillingCalculation(product, term, billing) {
  let raw = product["ERP Price"] || "";
  if (raw) raw = raw.toString().replace(",", ".");
  const base = parseFloat(raw);

  if (isNaN(base)) return null;

  if (term === "P1Y" && billing === "Monthly") {
    return base / 12;
  }

  if (term === "P3Y" && billing === "Annual") {
    return base / 3;
  }

  if (term === "P3Y" && billing === "Monthly") {
    return base / 36;
  }

  return null;
}

/* ---------------- RENDER ---------------- */
function renderResults(list) {
  const container = document.getElementById("results");
  container.innerHTML = "";

  if (!list.length) {
    const empty = document.createElement("div");
    empty.textContent = "No products found.";
    empty.style.fontSize = "12px";
    empty.style.color = "#9ca3af";
    container.appendChild(empty);
    return;
  }

  list.forEach(item => {
    let finalItem = item;

    if (activeView === "nce") {
      const term = document.getElementById("termFilter").value;
      const billing = document.getElementById("billingFilter").value;

      const adjusted = applyBillingCalculation(item, term, billing);

      if (adjusted !== null) {
        finalItem = {
          ...item,
          Price: adjusted.toFixed(2)
        };
      }
    }

    const card = activeView === "nce"
      ? createNceCard(finalItem)
      : createSoftwareCard(finalItem);

    container.appendChild(card);
  });
}

/* ---------------- SEARCH HANDLER ---------------- */
function handleSearch() {
  const query = document.getElementById("search").value;
  const segment = document.getElementById("segmentFilter").value;
  const billing = document.getElementById("billingFilter").value;
  const term = document.getElementById("termFilter").value;
  const tag = document.getElementById("tagFilter").value;

  const filters = { segment, billing, term, tag };
  const results = getResults(query, filters);

  renderResults(results);
}

/* ---------------- VIEW SWITCH ---------------- */
function switchView(view) {
  activeView = view;
  document.getElementById("search").value = "";

  document.body.classList.remove("theme-nce", "theme-software");
  document.body.classList.add(view === "nce" ? "theme-nce" : "theme-software");

  document.getElementById("nceView").classList.toggle("active", view === "nce");
  document.getElementById("softwareView").classList.toggle("active", view === "software");

  activeProducts = view === "nce" ? nceProducts : softwareProducts;

  buildFilters(activeProducts);
  handleSearch();
}

/* ---------------- INIT ---------------- */
document.addEventListener("DOMContentLoaded", async () => {
  document.body.classList.add("theme-nce");

  nceProducts = await loadCSV(
    "data/products.csv",
    `https://raw.githubusercontent.com/lyndendelacruz/data/main/products.csv?cb=${Date.now()}`,
    "products.csv"
  );

  softwareProducts = await loadCSV(
    "data/software.csv",
    `https://raw.githubusercontent.com/lyndendelacruz/data/main/software.csv?cb=${Date.now()}`,
    "software.csv"
  );

  softwareProducts = softwareProducts.filter(p => p.Currency === "GBP");

  activeProducts = nceProducts;
  buildFilters(activeProducts);
  renderResults(activeProducts);

  document.getElementById("search")
    .addEventListener("input", debounce(handleSearch, 150));

  document.getElementById("segmentFilter")
    .addEventListener("change", handleSearch);

  document.getElementById("billingFilter")
    .addEventListener("change", handleSearch);

  document.getElementById("termFilter")
    .addEventListener("change", handleSearch);

  document.getElementById("tagFilter")
    .addEventListener("change", handleSearch);

  document.getElementById("nceView")
    .addEventListener("click", () => switchView("nce"));

  document.getElementById("softwareView")
    .addEventListener("click", () => switchView("software"));
});
import { getSegmentIconClass } from "../../popup.js";

/* ---------------- SVG ICONS ---------------- */
function getSegmentIconSVG(segment) {
  const cls = getSegmentIconClass(segment);

  if (cls === "segment-commercial") {
    return `<svg viewBox="0 0 24 24" class="seg-icon"><path d="M10 2h4a2 2 0 0 1 2 2v2h4v14H4V6h4V4a2 2 0 0 1 2-2zm0 4h4V4h-4v2z"/></svg>`;
  }

  if (cls === "segment-education") {
    return `<svg viewBox="0 0 24 24" class="seg-icon"><path d="M12 3l10 5-10 5L2 8l10-5zm0 7l6.5-3.25L12 3.5 5.5 6.75 12 10zm-7 2.5v3l7 3.5 7-3.5v-3l-7 3.5-7-3.5z"/></svg>`;
  }

  if (cls === "segment-charity") {
    return `<svg viewBox="0 0 24 24" class="seg-icon"><path d="M12 21s-6.7-4.35-9.33-8.28C-1.33 7.8 2.24 2 7.5 2c2.54 0 4.5 1.5 4.5 1.5S14.96 2 17.5 2C22.76 2 26.33 7.8 21.33 12.72 18.7 16.65 12 21 12 21z"/></svg>`;
  }

  return `<svg viewBox="0 0 24 24" class="seg-icon"><circle cx="12" cy="12" r="5"/></svg>`;
}

/* ---------------- CALCULATOR PANEL ---------------- */
function createCalculatorPanel(card, priceValue, currencySymbol, includeNceButton) {
  const panel = document.createElement("div");
  panel.className = "calc-panel";

  panel.innerHTML = `
    <label>Quantity:</label>
    <input type="number" min="1" value="1" class="qty-input">

    <div class="total-line">
      <strong>Total:</strong>
      <span class="total-value">
        <span class="currency">${currencySymbol}</span>
        <span class="amount">${priceValue.toFixed(2)}</span>
      </span>
    </div>
  `;

  /* --- BUTTONS --- */
  const buttons = document.createElement("div");
  buttons.className = "calc-buttons";

  if (includeNceButton) {
    buttons.innerHTML = `
      <div class="copy-nce-btn" title="Copy NCE row">NCE Copy</div>
      <div class="copy-btn" title="Copy product details">Copy</div>
    `;
  } else {
    buttons.innerHTML = `
      <div class="copy-btn" title="Copy product details">Copy</div>
    `;
  }

  panel.appendChild(buttons);

  /* --- Quantity logic --- */
  const qtyInput = panel.querySelector(".qty-input");
  const totalValue = panel.querySelector(".total-value");

  qtyInput.addEventListener("input", () => {
    const qty = parseInt(qtyInput.value) || 0;
    const total = qty * priceValue;

    totalValue.innerHTML = `
      <span class="currency">${currencySymbol}</span>
      <span class="amount">${total.toFixed(2)}</span>
    `;

    const erpBadge = card.querySelector(".erp-price");
    if (erpBadge) {
      const baseErp = parseFloat(erpBadge.dataset.erp);
      const erpTotal = qty * baseErp;

      const erpAmountEl = erpBadge.querySelector(".erp-amount");
      if (erpAmountEl) {
        erpAmountEl.textContent = erpTotal.toFixed(2);
      }
    }
  });

  return panel;
}

/* ---------------- NCE CARD ---------------- */
export function createNceCard(product) {
  const card = document.createElement("div");
  card.className = "product-card";

  const title = product.ProductTitle || "Untitled";
  const sku = product.SkuId || "";
  const productId = product.ProductId || "";
  const billing = product.BillingPlan || "";
  const segment = product.Segment || "";
  const currency = product.Currency || "";

  let rawPrice = product.Price || product["ERP Price"] || "";
  if (rawPrice) rawPrice = rawPrice.toString().replace(",", ".");
  const priceValue = parseFloat(rawPrice) || 0;

  let erpRaw = product["ERP Price"] || "";
  if (erpRaw) erpRaw = erpRaw.toString().replace(",", ".");
  const erpValue = parseFloat(erpRaw) || null;

  const iconClass = getSegmentIconClass(segment);
  const iconSVG = getSegmentIconSVG(segment);

  card.innerHTML = `
    <div class="product-header">
      <div class="product-name ${iconClass}">
        ${iconSVG}
        ${title}
      </div>
    </div>

    <div class="product-meta">
      ${sku ? `<span class="product-sku">SKU: ${sku}</span>` : ""}
      ${productId ? `<span class="product-id">Product ID: ${productId}</span>` : ""}

      ${billing ? `<span class="badge">${billing}</span>` : ""}
      ${segment ? `<span class="badge">${segment}</span>` : ""}

      <span class="badge price">
        <span class="currency">${currency}</span>
        <span class="amount">${priceValue.toFixed(2)}</span>
      </span>

      ${
        erpValue && erpValue !== priceValue
          ? `
        <span class="badge erp-price" data-erp="${erpValue}">
          ERP: ${currency} <span class="erp-amount">${erpValue.toFixed(2)}</span>
        </span>
      `
          : ""
      }
    </div>
  `;

  const calcPanel = createCalculatorPanel(card, priceValue, currency, true);
  card.appendChild(calcPanel);

  /* ---------------- COPY BUTTON ---------------- */
  const copyBtn = card.querySelector(".copy-btn");

  copyBtn.addEventListener("click", (e) => {
    e.stopPropagation();

    const qty = parseInt(card.querySelector(".qty-input").value) || 1;
    const adjustedTotal = (priceValue * qty).toFixed(2);

    const text = `
Product: ${title}
SKU: ${sku}
Product ID: ${productId}
Term: ${product.TermDuration || "N/A"}
Billing Plan: ${billing}
Segment: ${segment}
Quantity: ${qty}
Total: GBP ${adjustedTotal}
    `.trim();

    navigator.clipboard.writeText(text);

    copyBtn.textContent = "Copied!";
    setTimeout(() => (copyBtn.textContent = "Copy"), 1200);
  });

  /* ---------------- NCE COPY BUTTON ---------------- */
  const copyNceBtn = card.querySelector(".copy-nce-btn");

  copyNceBtn.addEventListener("click", (e) => {
    e.stopPropagation();

    const qty = parseInt(card.querySelector(".qty-input").value) || 1;

    const row = [
      productId,
      sku,
      product.TermDuration || "N/A",
      billing,
      segment,
      qty
    ].join("\t");

    navigator.clipboard.writeText(row);

    copyNceBtn.textContent = "Copied!";
    setTimeout(() => (copyNceBtn.textContent = "NCE Copy"), 1200);
  });

  return card;
}

/* ---------------- SOFTWARE CARD ---------------- */
export function createSoftwareCard(product) {
  const card = document.createElement("div");
  card.className = "product-card";

  const title = product.ProductTitle || "Untitled";
  const sku = product.SkuId || "";
  const productId = product.ProductId || "";
  const billing = product.BillingPlan || "";
  const segment = product.Segment || "";
  const currency = product.Currency || "";
  const tags = (product.Tags || "").split(";").filter(Boolean);
  const priceValue = parseFloat(product.ERP || 0);

  const iconClass = getSegmentIconClass(segment);
  const iconSVG = getSegmentIconSVG(segment);

  card.innerHTML = `
    <div class="product-header">
      <div class="product-name ${iconClass}">
        ${iconSVG}
        ${title}
      </div>
    </div>

    <div class="product-meta">
      ${sku ? `<span class="product-sku">SKU: ${sku}</span>` : ""}
      ${productId ? `<span class="product-id">Product ID: ${productId}</span>` : ""}

      ${billing ? `<span class="badge">${billing}</span>` : ""}
      ${segment ? `<span class="badge">${segment}</span>` : ""}
      ${currency ? `<span class="badge">${currency}</span>` : ""}
      ${tags.map(t => `<span class="badge">${t}</span>`).join("")}

      <span class="badge price">
        <span class="currency">${currency}</span>
        <span class="amount">${priceValue.toFixed(2)}</span>
      </span>
    </div>
  `;

  const calcPanel = createCalculatorPanel(card, priceValue, currency, false);
  card.appendChild(calcPanel);

  /* ---------------- COPY BUTTON ---------------- */
  const copyBtn = card.querySelector(".copy-btn");

  copyBtn.addEventListener("click", (e) => {
    e.stopPropagation();

    const qty = parseInt(card.querySelector(".qty-input").value) || 1;
    const total = (priceValue * qty).toFixed(2);

    const text = `
${title}
SKU: ${sku}
Product ID: ${productId}
Billing: ${billing}
Segment: ${segment}

Price: ${currency} ${priceValue.toFixed(2)}
Quantity: ${qty}
Total: ${currency} ${total}
    `.trim();

    navigator.clipboard.writeText(text);

    copyBtn.textContent = "Copied!";
    setTimeout(() => (copyBtn.textContent = "Copy"), 1200);
  });

  return card;
}
export function parseCSV(text) {
  // Normalize line endings and remove BOM
  text = text.replace(/^\uFEFF/, "").replace(/\r/g, "");

  const lines = text.split("\n").filter(l => l.trim().length > 0);
  if (lines.length <= 1) return [];

  // Detect delimiter: TSV > semicolon > comma
  const headerLine = lines[0];
  let delimiter = ",";

  if (headerLine.includes("\t")) delimiter = "\t";
  else if (headerLine.includes(";")) delimiter = ";";

  const headers = splitLine(headerLine, delimiter);

  const rows = [];

  for (let i = 1; i < lines.length; i++) {
    const values = splitLine(lines[i], delimiter);
    const obj = {};

    headers.forEach((h, idx) => {
      obj[h.trim()] = values[idx] !== undefined ? values[idx].trim() : "";
    });

    rows.push(obj);
  }

  return rows;
}

// Robust splitter that respects quotes and escaped quotes
function splitLine(line, delimiter) {
  const result = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const next = line[i + 1];

    // Escaped quote ("")
    if (char === '"' && next === '"') {
      current += '"';
      i++;
      continue;
    }

    // Toggle quote mode
    if (char === '"') {
      inQuotes = !inQuotes;
      continue;
    }

    // Delimiter outside quotes
    if (char === delimiter && !inQuotes) {
      result.push(current);
      current = "";
      continue;
    }

    current += char;
  }

  result.push(current);
  return result;
}